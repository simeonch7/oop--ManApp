﻿using System;
namespace MngApp
{
    public class Employee : Intern
    {
        public int Salary { get; set; }

        public Employee(int Id, string Name, int Salary) : base(Id, Name)
        {
            this.Salary = Salary;
        }

        public Employee()
        {
        }

        public override string GetMyRank()
        {
            return "I am an employee!";
        }


        public int GetSalary()
        {
            return Salary;
        }
    }
}
