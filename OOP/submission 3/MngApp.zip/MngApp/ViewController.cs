﻿using System;
using System.Collections.Generic;
using System.Text;
using AppKit;
using Foundation;
using System.Xml.Serialization;
using System.IO;
using System.Text.RegularExpressions;


namespace MngApp
{
    public partial class ViewController : NSViewController
    {
        public int startID = 1000;

        Company currentCompany = new Company(0);

        private RegexClass regexes = new RegexClass();

        public ViewController(IntPtr handle) : base(handle)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
        }

        public override NSObject RepresentedObject
        {
            get
            {
                return base.RepresentedObject;
            }
            set
            {
                base.RepresentedObject = value;
                // Update the view, if already loaded.
            }
        }

        partial void ChangePositionDropDown(NSObject sender)
        {
            if (EmployeePosition.TitleOfSelectedItem == "Manager")
            {
                LevelTextField.Hidden = false;
                SalaryTextField.Hidden = false;
            }
            else if (EmployeePosition.TitleOfSelectedItem == "Employee")
            {
                LevelTextField.Hidden = true;
                SalaryTextField.Hidden = false;

            }
            else if (EmployeePosition.TitleOfSelectedItem == "Intern")
            {
                LevelTextField.Hidden = true;
                SalaryTextField.Hidden = true;
            }
        }

        partial void BudgetButton(NSObject sender)
        {
            Match matchBudget = regexes.GetRegexSalary().Match(BudgetTextField.StringValue);

            if (matchBudget.Success)
            {
                currentCompany.Budget = BudgetTextField.IntValue;
                BudgetLabel.StringValue = "Budget left: " + currentCompany.GetBudgetLeft().ToString();
            }
            else
            {
                AlertFunc("Please enter a valid budget!");
            }
        }

        partial void AddEmployeeButton(NSObject sender)
        {
            if (EmployeePosition.TitleOfSelectedItem == "Manager")
            {
                Match matchName = regexes.GetRegexName().Match(NameTextField.StringValue);
                Match matchSalary = regexes.GetRegexSalary().Match(SalaryTextField.StringValue);

                if (matchName.Success && matchSalary.Success)
                {
                    if (LevelTextField.StringValue == "")
                    {
                        Manager manager = new Manager(IDGenerator(),
                           NameTextField.StringValue, Int32.Parse(SalaryTextField.StringValue));

                        if (currentCompany.Hire(manager) == true)
                        {
                            isAddingSuccessfulLabel.StringValue = "Added successfully - ID : " + manager.Id;
                            BudgetLabel.StringValue = "Budget left: " + currentCompany.GetBudgetLeft().ToString();
                        }
                        else
                        {
                            isAddingSuccessfulLabel.StringValue = "Not enough budget left!";
                        }
                    }
                    else
                    {
                        Match matchLevel = regexes.GetRegexLevel().Match(LevelTextField.StringValue);
                        if (matchLevel.Success)
                        {


                            Manager manager = new Manager(IDGenerator(), NameTextField.StringValue,
                               SalaryTextField.IntValue, Int32.Parse(LevelTextField.StringValue));

                            if (currentCompany.Hire(manager) == true)
                            {
                                isAddingSuccessfulLabel.StringValue = "Added successfully - ID : " + manager.Id;
                                BudgetLabel.StringValue = "Budget left: " + currentCompany.GetBudgetLeft().ToString();
                            }
                            else
                            {
                                isAddingSuccessfulLabel.StringValue = "Not enough budget left!";
                            };
                        }
                        else
                        {
                            AlertFunc("You have entered an invalid level (min. 1, max. 9)");
                        }
                    }
                }
                else
                {
                    AlertFunc("You have entered either invalid name or salary, please double-check");
                }
            }
            else if (EmployeePosition.TitleOfSelectedItem == "Employee")
            {
                Match matchName = regexes.GetRegexName().Match(NameTextField.StringValue);
                Match matchSalary = regexes.GetRegexSalary().Match(SalaryTextField.StringValue);

                if (matchName.Success && matchSalary.Success)
                {
                    Employee employee = new Employee(IDGenerator(), NameTextField.StringValue,
                    Int32.Parse(SalaryTextField.StringValue));
                    if (currentCompany.Hire(employee) == true)
                    {
                        isAddingSuccessfulLabel.StringValue = "Added successfully - ID : " + employee.Id;
                        BudgetLabel.StringValue = "Budget left: " + currentCompany.GetBudgetLeft().ToString();

                    }
                    else
                    {
                        isAddingSuccessfulLabel.StringValue = "Not enough budget left!";
                    }
                }
                else
                {
                    AlertFunc("You have entered either invalid name or salary, please double-check");
                }
            }
            else if (EmployeePosition.TitleOfSelectedItem == "Intern")
            {

                Match matchName = regexes.GetRegexName().Match(NameTextField.StringValue);

                if (matchName.Success)
                {
                    Intern intern = new Intern(IDGenerator(), NameTextField.StringValue);
                    currentCompany.Hire(intern);
                    isAddingSuccessfulLabel.StringValue = "Added successfully - ID : " + intern.Id;
                    BudgetLabel.StringValue = "Budget left: " + currentCompany.GetBudgetLeft().ToString();
                }
                else
                {
                    AlertFunc("Please enter a valid name!");
                }
            }
        }

        partial void RemoveByIDButton(NSObject sender)
        {
            foreach (Intern intern in currentCompany.AllEmployees)
            {
                if (intern.Id == IDRemoveTextField.IntValue)
                {
                    currentCompany.Fire(intern);
                    break;
                }
            }
            BudgetLabel.StringValue = "Budget left: " + currentCompany.GetBudgetLeft().ToString();
        }

        partial void CloseCompanyButton(NSObject sender)
        {
            currentCompany.Close();
            BudgetLabel.StringValue = "Budget left: " + currentCompany.GetBudgetLeft().ToString();
        }


        partial void ListEmployeesButton(NSObject sender)
        {
            StringBuilder sb = new StringBuilder();

            foreach (var emp in currentCompany.AllEmployees)
            {
                //                String role = emp.ToString();
                //                role = role.Substring(7);
                if (emp is Manager)
                {
                    sb.Append("EmpID: " + emp.Id + ", Name: " + emp.GetName() + ", Role: "
                        + ((Manager)emp).GetMyRank() + ", Salary: " + ((Employee)emp).GetSalary()
                        + ", Level: " + ((Manager)emp).GetLevel() + "\n");
                }
                else if (emp is Employee)
                {
                    sb.Append("EmpID: " + emp.Id + ", Name: " + emp.GetName() + ", Role: "
                        + ((Employee)emp).GetMyRank() + ", Salary: " + ((Employee)emp).GetSalary() + "\n");
                }
                else
                {
                    sb.Append("EmpID: " + emp.Id + ", Name: " + emp.GetName() +
                        ", Role: " + ((Intern)emp).GetMyRank() + "\n");
                }
            }

            AllEmployeesLabel.StringValue = sb.ToString();
        }

        partial void FilterByLevelButton(NSObject sender)
        {
            List<Manager> managers = new List<Manager>();
            managers = currentCompany.GetManagersWithLevel(LevelToFilterTextField.IntValue);

            StringBuilder sb = new StringBuilder();

            foreach (var manager in managers)
            {
                sb.Append("EmpID: " + manager.Id + ", Name: " + manager.GetName() + ", Salary: " + manager.GetSalary() + "\n");
            }

            FilteredManagersLabel.StringValue = sb.ToString();
        }


        public int IDGenerator()
        {
            startID++;
            return startID;
        }

        partial void ExportXMLButton(NSObject sender)
        {
            List<Manager> managers = new List<Manager>();
            foreach (Intern manager in currentCompany.AllEmployees)
            {
                if (manager is Manager) managers.Add((Manager)manager);
            }

            List<Employee> employees = new List<Employee>();
            foreach (Intern employee in currentCompany.AllEmployees)
            {
                if (!(employee is Manager) && (employee is Employee)) employees.Add((Employee)employee);
            }

            List<Intern> interns = new List<Intern>();
            foreach (Intern intern in currentCompany.AllEmployees)
            {
                if (!(intern is Manager) && !(intern is Employee)) interns.Add(intern);
            }

             string fileNameIntern = "ExportedDataIntern" + "-" + DateTime.Now.Ticks;
             FileInfo fileIntern = new FileInfo(fileNameIntern + ".xml");
             StreamWriter swIntern = fileIntern.AppendText();
             var writerInterns = new System.Xml.Serialization.XmlSerializer(typeof(List<Intern>));
             writerInterns.Serialize(swIntern, interns);
             swIntern.Dispose();
             swIntern.Close();
             fileIntern.CopyTo("/Users/simeoch/Desktop");

             string fileNameEmployee = "ExportedDataEmployee" + "-" + DateTime.Now.Ticks;
             FileInfo fileEmployee = new FileInfo(fileNameEmployee + ".xml");
             StreamWriter swEmployee = fileEmployee.AppendText();
             var writerEmployees = new System.Xml.Serialization.XmlSerializer(typeof(List<Employee>));
             writerEmployees.Serialize(swEmployee, employees);
             swEmployee.Dispose();
             swEmployee.Close();
             fileEmployee.CopyTo("/Users/simeoch/Desktop");


             string fileNameManager = "ExportedDataManager" + "-" + DateTime.Now.Ticks;
             FileInfo fileManager = new FileInfo(fileNameManager + ".xml");
             StreamWriter swManager = fileManager.AppendText();
             var writerManager = new System.Xml.Serialization.XmlSerializer(typeof(List<Manager>));
             writerManager.Serialize(swManager, managers);
             swManager.Dispose();
             swManager.Close();
             fileManager.CopyTo("/Users/simeoch/Desktop");
        }

        partial void ImportXMLButton(NSObject sender)
        {
            var dlg = NSOpenPanel.OpenPanel;
            dlg.CanChooseFiles = true;
            dlg.AllowsMultipleSelection = true;
            dlg.CanChooseDirectories = false;
            dlg.AllowedFileTypes = new string[] { "xml" };

            if (dlg.RunModal() == 1)
            {
                for (int i = 0; i < dlg.Urls.Length; i++)
                {
                    var url = dlg.Urls[i];
                    var filePath = url.ToString().Substring(7);
                    if (filePath.Contains("ExportedDataIntern"))
                    {
                        XmlSerializer serializer = new XmlSerializer(typeof(List<Intern>));

                        using (FileStream stream = File.OpenRead(filePath))
                        {
                            List<Intern> dezerializedList = (List<Intern>)serializer.Deserialize(stream);
                            foreach (var item in dezerializedList)
                            {
                                currentCompany.AllEmployees.Add(item);
                            }
                        }

                    }
                    if (filePath.Contains("ExportedDataEmployee"))
                    {
                        XmlSerializer serializer = new XmlSerializer(typeof(List<Employee>));

                        using (FileStream stream = File.OpenRead(filePath))
                        {
                            List<Employee> dezerializedList = (List<Employee>)serializer.Deserialize(stream);
                            foreach (var item in dezerializedList)
                            {
                                currentCompany.AllEmployees.Add(item);
                            }
                        }

                    }
                    if (filePath.Contains("ExportedDataManager"))
                    {
                        XmlSerializer serializer = new XmlSerializer(typeof(List<Manager>));

                        using (FileStream stream = File.OpenRead(filePath))
                        {
                            List<Manager> dezerializedList = (List<Manager>)serializer.Deserialize(stream);
                            foreach (var item in dezerializedList)
                            {
                                currentCompany.AllEmployees.Add(item);
                            }
                        }
                    }
                }
            }
        }
        private void AlertFunc(string mssg)
        {
            var alert = new NSAlert()
            {
                AlertStyle = NSAlertStyle.Critical,
                InformativeText = mssg,
                MessageText = "OK",
            };
            alert.RunModal();
        }
    }
}
