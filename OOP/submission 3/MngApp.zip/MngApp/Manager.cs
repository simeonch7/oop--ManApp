﻿using System;
namespace MngApp
{
    public class Manager : Employee
    {
        public int Level { get; set; }

        public Manager(int Id, string Name, int Salary, int Level) : base(Id, Name, Salary)
        {
            this.Level = Level;
        }

        public Manager()
        {
        }

        //if no level is specified, manager is created of level 1
        public Manager(int Id, string Name, int Salary) : base(Id, Name, Salary)
        {
            Level = 1;
        }

        public int GetLevel()
        {
            return Level;
        }

        public override string GetMyRank()
        {
            return "I am a manager!";
        }
    }
}
