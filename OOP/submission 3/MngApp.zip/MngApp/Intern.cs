﻿using System;
namespace MngApp
{
    public class Intern
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public Intern(int Id, string Name)
        {
            this.Id = Id;
            this.Name = Name;
        }
        public Intern() {
        }

        public string GetName() {
            return Name;
        }

        public virtual string GetMyRank()
        {
            return "I am an intern!";
        }
    }
}
