﻿using System;
using System.Collections.Generic;

namespace MngApp
{
    public class Company
    {
        public int Budget { get; set; }

        /*(thanks to polymorphism i can treat every derived class as the
        base one and add an object of derived class to a list of base class)*/
        public List<Intern> AllEmployees = new List<Intern>();

        public Company(int Budget)
        {
            this.Budget = Budget;
        }

        public bool Hire(Intern e)
        {
            if (e is Employee)
            {
                if (GetBudgetLeft() >= ((Employee)e).GetSalary())
                {
                    AllEmployees.Add(e);
                    return true;
                }
            }
            else
            {
                AllEmployees.Add(e);
                return true;
            }

            return false;
        }


        public void Fire(Intern intern)
        {
            AllEmployees.Remove(intern);
        }


        public bool IsHired(Intern intern)
        {
            return AllEmployees.Contains(intern);
        }

        /**
         * Closes the company. Sets the budget to 0 and fires all employees
         */
        public void Close()
        {
            AllEmployees.Clear();
            Budget = 0;
        }

        public double GetBudgetLeft()
        {
            int tempBudget = Budget;
            //either employee or manager (as intern does not receive salary)

            foreach (Intern intern in AllEmployees)
            {
                if (intern is Employee)
                {
                    tempBudget = tempBudget - ((Employee)intern).GetSalary();
                }
            }
            return tempBudget;
        }

        public List<Manager> GetManagersWithLevel(int level)
        {
            List<Manager> managers = new List<Manager>();
            foreach (Intern intern in AllEmployees)
            {
                if (intern is Manager)
                {

                    if (((Manager)intern).GetLevel() == level)
                    {
                        managers.Add((Manager)intern);
                    }

                }
            }
            return managers;
        }

    }
}