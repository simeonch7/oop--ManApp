﻿using System;
using System.Text.RegularExpressions;

namespace MngApp
{
    public class RegexClass
    {
        private Regex rgxName = new Regex(@"^[a-z][a-z\s]*$");
        private Regex rgxSalary = new Regex(@"^\d+$");
        private Regex rgxLevel = new Regex(@"^\d$");

        public Regex GetRegexSalary()
        {
            return rgxSalary;
        }
        public Regex GetRegexName()
        {
            return rgxName;
        }
        public Regex GetRegexLevel()
        {
            return rgxLevel;
        }
    }
}
